export class Cliente {
    nome;
    cognome;
}